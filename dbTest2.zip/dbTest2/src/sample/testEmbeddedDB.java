package sample;

import org.apache.derby.jdbc.EmbeddedXADataSource;

import java.sql.*;


public class testEmbeddedDB {

    public testEmbeddedDB(){
        final String url = "jdbc:derby:testEmbedded";

        try{
            Connection c = DriverManager.getConnection(url);

            //testEmbeddedDB.dropTables(c);

            testEmbeddedDB.createTable(c);

            /*createcoffeedb.buildCoffeeTable(c);
            createcoffeedb.buildCustomerTable(c);
            createcoffeedb.buildUnpaidOrderTable(c);*/

            /*Statement s = c.createStatement();
            ResultSet r = s.executeQuery("SELECT PRICE FROM COFFEE");

            while(r.next()){
                double price = r.getDouble("PRICE");
                System.out.println("price: " + price);
            }*/



        } catch (Exception e){
            System.out.println("Error Creating the Coffee Table");
            System.out.println(e.getMessage());
        }
    }

    public static void dropTables(Connection c){
        try{
            Statement s = c.createStatement();
            s.execute("DROP TABLE Nodes");
            System.out.println("Nodes dropped.");

            s.execute("DROP TABLE Edges");
            System.out.println("Edges dropped.");

        } catch (Exception e){
            System.out.println("error: " + e.getMessage());
        }
    }

    public static void createTable(Connection c){

        try{
            Statement s = c.createStatement();

            // Create the table.
            s.execute("CREATE TABLE Nodes (" +
                    "nodeID CHAR(25) NOT NULL PRIMARY KEY, " +
                    "xcord INTEGER, " +
                    "ycord INTEGER, " +
                    "floor CHAR(4), " +
                    "building CHAR(15), " +
                    "nodeType CHAR(4), " +
                    "longName CHAR(25), " +
                    "shortName CHAR(12), " +
                    "teamAssigned CHAR(1)" +
                    ")");

            s.execute("CREATE TABLE Edges (" +
                    "edgeID CHAR(25) NOT NULL PRIMARY KEY, " +
                    "startNode CHAR(25), " +
                    "endNode CHAR(25)" +
                    ")");

            System.out.println("done");
        } catch (Exception e){
            System.out.println("ERROR: " + e.getMessage());
        }

    }



}
